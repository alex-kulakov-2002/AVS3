from figure import *
import math


# Класс тэтраэдра.
class Tetrahedron(Figure):
    def __init__(self):
        self.side = 0

    # Создание тэтраэдра по данным из общего массива.
    def ReadStrArray(self, strArray, i):
        self.side = int(strArray[i])
        i += 1
        return i

    def Print(self):
        print(f"It is a Tetrahedron:\n"
              f"\tside = {self.side}\n"
              f"\tVolume = {self.Volume()}")

    def Write(self, ostream):
        ostream.write(f"It is a Tetrahedron:\n"
                      f"\tside = {self.side}\n"
                      f"\tVolume = {self.Volume()}")
        pass

    def Volume(self):
        return float(2**0.5 * self.side**3 / 10)