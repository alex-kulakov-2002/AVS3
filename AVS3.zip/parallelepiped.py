from figure import *
import math


# Класс параллелепипеда.
class Parallelepiped(Figure):
    def __init__(self):
        self.side1 = 0
        self.side2 = 0
        self.side3 = 0

    # Создание параллелепипеда по данным из общего массива.
    def ReadStrArray(self, strArray, i):
        self.side1 = int(strArray[i])
        self.side2 = int(strArray[i+1])
        self.side3 = int(strArray[i+2])
        i += 3
        return i

    def Print(self):
        print(f"It is a Parallelepiped:\n"
              f"\tside1 = {self.side1}\n"
              f"\tside2 = {self.side2}\n"
              f"\tside3 = {self.side3}\n"
              f"\tVolume = {self.Volume()}")

    def Write(self, ostream):
        ostream.write(f"It is a Parallelepiped:\n"
              f"\tside1 = {self.side1}\n"
              f"\tside2 = {self.side2}\n"
              f"\tside3 = {self.side3}\n"
              f"\tVolume = {self.Volume()}")

    def Volume(self):
        return float(self.side1*self.side2*self.side3)