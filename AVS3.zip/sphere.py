from figure import *
import math

# Класс сферы.
class Sphere(Figure):
    def __init__(self):
        self.r = 0

    # Создание сферы по данным из общего массива.
    def ReadStrArray(self, strArray, i):
        self.r = int(strArray[i])
        i += 1
        return i

    def Print(self):
        print(f"It is a Sphere:\n"
              f"\tr = {self.r}\n"
              f"\tVolume = {self.Volume()}")

    def Write(self, ostream):
        ostream.write(f"It is a Sphere:\n"
              f"\tr = {self.r}\n"
              f"\tVolume = {self.Volume()}")

    def Volume(self):
        return float(4/3 * math.pi * self.r**3)