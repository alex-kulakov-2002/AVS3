from figure import *
from tetrahedron import *
from parallelepiped import *
from sphere import *
from exceptions import *
from generate import *
from random import *

from container import *


class Container:
    def __init__(self):
        self.store = []

    def Print(self):
        print("Container is store", len(self.store), "figures:")
        for figure in self.store:
            figure.Print()

    def Write(self, ostream):
        ostream.write("Container is store {} figures:\n".format(len(self.store)))
        for figure  in self.store:
            figure.Write(ostream)
            ostream.write("\n")

    # Вычисление среднего объема фигуры в контейнере.
    def GetAverageVolume(self) -> float:
        volumeSum = 0.0
        for figure in self.store:
            volumeSum += figure.Volume()
        return volumeSum / (len(self.store) if len(self.store) != 0 else 1)

    # Сдвиг в конец всех фигур, объем которых больше среднего.
    def ShiftByVolume(self):
        average = self.GetAverageVolume()
        i = 0
        j = 0
        while j < len(self.store):
            if self.store[j].Volume() < average:
                if (i == j):
                    i += 1
                    j += 1
                else:
                    j += 1
            else:
                if i >= len(self.store):
                    break
                if (self.store[i].Volume() <= average):
                    fig = self.store[i]
                    self.store[i] = self.store[j]
                    self.store[j] = fig
                    i += 1
                    j += 1
                else:
                    i += 1
