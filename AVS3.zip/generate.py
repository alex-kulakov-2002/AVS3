import random
import sys
from figure import *
from tetrahedron import *
from parallelepiped import *
from sphere import *
from exceptions import *
from generate import *
from random import *

from container import *


class GeneratorAndWriter:
    # Генерация массива с информаице о рандомных фигурах.
    @staticmethod
    def RndGenerateArr(count) -> []:
        arr = []
        for i in range(count):
            key = random.randint(1, 3)
            arr.append(key)
            volume = random.randint(1, 1000)
            arr.append(volume)
            if key == 1:
                arr += GeneratorAndWriter.getCordsForTetrahedron()
            elif key == 2:
                arr += GeneratorAndWriter.getCordsForParallelepiped()
            elif key == 3:
                arr += GeneratorAndWriter.getCordsForSphere()
        return [str(x) for x in arr]

    # Генерация рандомных координат точек для треугольника.
    @staticmethod
    def getCordsForTetrahedron() -> []:
        side = random.randint(1, 1000)
        return [side]

    # Генерация рандомных координат точек для прямоугольника.
    @staticmethod
    def getCordsForParallelepiped() -> []:
        side1 = random.randint(1, 1000)
        side2 = random.randint(1, 1000)
        side3 = random.randint(1, 1000)
        return [side1, side2, side3]

    # Генерация рандомных координат точек для круга.
    @staticmethod
    def getCordsForSphere() -> []:
        r = random.randint(1, 1000)
        return [r]

    # Метод, который проверяет на возможность дальнешего считывания массива (вместе со смещением).
    # Если в массиве присутвуют строки,
    # которые не могут быть преобразованы в число или массив имеет недостаточную длину,
    # то пользователю выводится сообщение об ошибке, а приложение прекращает работу.
    @staticmethod
    def ConinueOrExit(start_index, count_of_offset, array):
        if start_index + count_of_offset > len(array):
            Exceptions.incorrectFileInput()
            sys.exit()
        for i in range(count_of_offset):
            if not array[start_index + i].isdigit():
                Exceptions.incorrectFileInput()
                sys.exit()

    @staticmethod
    def ReadStrArray(container, strArray) -> bool:
        arr_len = len(strArray)
        # Индекс, задающий текущую строку в массиве.
        i = 0
        while i < arr_len:
            GeneratorAndWriter.ConinueOrExit(i, 2, strArray)

            # Парсинг отличительного признака фигуры.
            key = int(strArray[i])
            volume = int(strArray[i+1])
            i += 2

            # Признак прямоугольника - 1, треугольика - 2, круга - 3.
            if key == 1:
                GeneratorAndWriter.ConinueOrExit(i, 1, strArray)
                figure = Tetrahedron()
                # Чтение прямоугольника с возвратом позиции за ним.
                i = figure.ReadStrArray(strArray, i)
            elif key == 2:
                GeneratorAndWriter.ConinueOrExit(i, 3, strArray)
                figure = Parallelepiped()
                # Чтение треугольника с возвратом позиции за ним.
                i = figure.ReadStrArray(strArray, i)
            elif key == 3:
                GeneratorAndWriter.ConinueOrExit(i, 1, strArray)
                figure = Sphere()
                # Чтение круга с возвратом позиции за ним.
                i = figure.ReadStrArray(strArray, i)
            else:
                # Если что-то пошло не так, вывод сообщения и выход из функции.
                print("Something went wrong!")
                return False
            figure.SetVolume(volume)
            container.store.append(figure)
        return True

    # Генерация рандомного теста с заданным количеством фигур
    # и запись полученного массива данных в файл.
    @staticmethod
    def WriteTest(count):
        str_arr = GeneratorAndWriter.RndGenerateArr(count)
        file = open("autoGenerateRandomTest.txt", 'w')
        i = 0
        while i < len(str_arr):
            key = int(str_arr[i])
            volume = int(str_arr[i + 1])
            i += 2
            file.write(f"{key} {volume}\n")
            if key == 1:
                file.write(f"{str_arr[i]}\n")
                i += 1
            elif key == 2:
                file.write(f"{str_arr[i]} {str_arr[i + 1]} {str_arr[i + 2]}\n")
                i += 3
            elif key == 3:
                file.write(f"{str_arr[i]}\n")
                i += 1
        file.close()