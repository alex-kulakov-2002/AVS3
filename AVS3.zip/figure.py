
class Figure:
    def __init__(self):
        self.volume = 0

    def SetVolume(self, volume):
        self.volume = volume

    def ReadStrArray(self, strArray, i):
        pass

    def Print(self):
        pass

    def Write(self, ostream):
        pass

    def Volume(self):
        pass